module.exports = {
  type: 'react-app'
}
