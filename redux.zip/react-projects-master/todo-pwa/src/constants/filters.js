// Constants for filter types

export const FILTER_ALL = 'FILTER_ALL';
export const FILTER_COMPLETED = 'FILTER_COMPLETED';
export const FILTER_ACTIVE = 'FILTER_ACTIVE';